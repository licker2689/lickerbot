package org.example;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.*;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.entities.channel.concrete.VoiceChannel;
import net.dv8tion.jda.api.events.GenericEvent;
import net.dv8tion.jda.api.events.guild.member.GuildMemberJoinEvent;
import net.dv8tion.jda.api.events.guild.member.GuildMemberRemoveEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.events.message.react.MessageReactionAddEvent;
import net.dv8tion.jda.api.events.session.ReadyEvent;
import net.dv8tion.jda.api.hooks.EventListener;
import net.dv8tion.jda.api.requests.GatewayIntent;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class ReadyListener implements EventListener {
    public static void main(String[] args)
            throws InterruptedException {
        // Note: It is important to register your ReadyListener before building
        JDA jda = JDABuilder.createDefault("MTAzNjgxNjMzMDU3NTMzNTUzNA.GFHzFW.N6T5IlSINGJepBkIRQls3VQ8COgdIHTpZlqmzA")
                .addEventListeners(new ReadyListener()).enableIntents(GatewayIntent.MESSAGE_CONTENT)
                .enableIntents(GatewayIntent.GUILD_MESSAGE_REACTIONS).enableIntents(GatewayIntent.DIRECT_MESSAGES)
                .enableIntents(GatewayIntent.GUILD_MEMBERS).enableIntents(GatewayIntent.GUILD_BANS)
                .enableIntents(GatewayIntent.DIRECT_MESSAGE_TYPING)
                .build();

        // optionally block until JDA is ready
        jda.awaitReady();
    }

    boolean flag = false;

    @Override
    public void onEvent(GenericEvent event) {

        if (event instanceof ReadyEvent) {

            System.out.println("API is ready!");

        }
        if (event instanceof GuildMemberJoinEvent) {

            if (((GuildMemberJoinEvent) event).getGuild().getName().equals("해마슈슈슉")) {
                System.out.println(((GuildMemberJoinEvent) event).getMember().getUser().getName() + ((GuildMemberJoinEvent) event).getGuild());
                Role r = ((GuildMemberJoinEvent) event).getGuild().getRoleById("1019811149602107402");
                User u = ((GuildMemberJoinEvent) event).getUser();
                ((GuildMemberJoinEvent) event).getGuild().addRoleToMember(u, r).complete();
            }
        }
        if (event instanceof MessageReceivedEvent) {
            Message m = ((MessageReceivedEvent) event).getMessage();
            Role r = ((MessageReceivedEvent) event).getGuild().getRoleById("1019811149602107402");
            System.out.println(m.getAuthor().getName() + " : " + m.getContentDisplay() + "라고 " + m.getChannel().getName() + "에서 보냈습니다.");
            if (m.getContentDisplay().contains("리꺼봇")) {
                if (isOwner(m.getAuthor().getName()) || isSeverOwner(((MessageReceivedEvent) event).getMember().getGuild().getOwnerId(), m.getAuthor())) {
                    m.getChannel().sendMessage("왜 부르시나요? 주인님?").queue();
                } else {
                    m.getChannel().sendMessage("왜 부르시나요? 주인님").delay(2, TimeUnit.SECONDS).queue(message -> message.editMessage("주인님이 아니잖아!").queue());


                }

                flag = true;
            }
            if (m.getContentDisplay().equals("코딩해줘") && flag) {
                if (isOwner(m.getAuthor().getName())) {
                    m.getChannel().sendMessage("정말 죄송하지만 주인님, 제 능력이 안되서 어려울것 같아요! 죄송해요!").queue();
                } else {
                    m.getChannel().sendMessage("싫어, 안 해!, 주인님 말만 들을꺼야!").queue();
                }

                flag = false;
            }
            if (m.getContentDisplay().equals("변신!") && flag) {
                if (isOwner(m.getAuthor().getName())) {
                    m.getChannel().sendMessage("으아아아아! 몸이! 몸이!").queue();
                } else {

                    m.getChannel().sendMessage("`삐빅, 명령 권한이 없습니다!` 랄까 나요?").queue();
                }

                flag = false;
            }
            if (m.getContentDisplay().contains("ㅋㅋㅋㅋ") && !m.getAuthor().isBot()) {
                sendLaugh(m);
            }
            if (m.getGuild().getName().equals("해마슈슈슉") && !m.getMember().getRoles().contains(r)){
                User u = ((MessageReceivedEvent) event).getAuthor();
                ((MessageReceivedEvent) event).getGuild().addRoleToMember(u, r).complete();
            }
        }
        if (event instanceof MessageReactionAddEvent) {
            MessageReaction m = ((MessageReactionAddEvent) event).getReaction();
            String pn = ((MessageReactionAddEvent) event).getUser().getId();
            TextChannel tch = ((MessageReactionAddEvent) event).getGuild().getTextChannelById("1022854891011579955");

            if (m.getMessageId().equals("921344892679110666")) {
                System.out.println("Reaction event");
                tch.sendMessage("<@" + pn + ">" + "님 인증해 주셔서 감사합니다! 서버에 오신것을 진심으로 환영해요!").queue();
            }
        }
        if (event instanceof GuildMemberRemoveEvent) {

            if (((GuildMemberRemoveEvent) event).getGuild().getName().equals("DPP 커뮤니티")){
                VoiceChannel vch = ((GuildMemberRemoveEvent) event).getGuild().getVoiceChannelById("987294824619200566");
                int psn = Integer.parseInt(vch.getName().replaceAll("\\D+", ""));
                psn = psn - 1;
                String s = String.valueOf(psn);
                vch.getManager().setName("인원:" + s);
            }
        }
    }

    public boolean isOwner(String name) {
        return name.equals("nleader22 [  ]") || name.equals("licker2689");
    }

    public boolean isSeverOwner(String s, User u) {
        return s.equals(u.getAvatarId());
    }

    public void sendLaugh(Message m) {
        if (SendLaugh.getCoolLaugh() == true) {
            Random r = new Random();
            int i = r.nextInt(11);
            if (i == 1) {
                m.getChannel().sendMessage("ㅋㅋㅋㅋㅋㅋㅋ").queue();
                SendLaugh.setCoolLaugh();
            }
            if (i == 2) {
                m.getChannel().sendMessage("ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ").queue();
                SendLaugh.setCoolLaugh();
            }
            if (i == 3) {
                m.getChannel().sendMessage("ㅋㅋㅋㅋㅋㅋㅋ").queue();
                SendLaugh.setCoolLaugh();
            }
            if (i == 4) {
                m.getChannel().sendMessage("겔겔겔겔겔").queue();
                SendLaugh.setCoolLaugh();
            }
            if (i == 5) {
                m.getChannel().sendMessage("ㅋㅋㅋㅋㅋㅋㅋ").queue();
                SendLaugh.setCoolLaugh();
            }
            if (i == 6) {
                m.getChannel().sendMessage("ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ").queue();
                SendLaugh.setCoolLaugh();
            }
            if (i == 7) {
                m.getChannel().sendMessage("ㅋㅋㅋㅋㅋㅋㅋ").queue();
                SendLaugh.setCoolLaugh();
            }
            if (i == 8) {
                m.getChannel().sendMessage("겔겔겔겔겔").queue();
                SendLaugh.setCoolLaugh();
            }
            if (i == 9) {
                m.getChannel().sendMessage("ㅋㅋㅋㅋㅋㅋㅋ").queue();
                SendLaugh.setCoolLaugh();
            }
            if (i == 10) {
                m.getChannel().sendMessage("배 아프니까 그만웃겨요").queue();
                SendLaugh.setCoolLaugh();
            }
        }
    }
}

